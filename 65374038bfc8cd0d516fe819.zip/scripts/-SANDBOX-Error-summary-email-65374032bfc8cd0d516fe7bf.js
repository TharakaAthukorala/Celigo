const ErrorSummaryEmail = {
  
  emailBodyTemplates: {
    mainArticle: (integrationName, stepErrorSections) => {
      return `<article
        style="font-family: 'Google Sans',Roboto,RobotoDraft,Helvetica,Arial,sans-serif,serif;width: 90%;margin: 0 auto;background-color: #F0F0EE">
    <div style="background-color: #f35c17; color: #FFFFFF; padding: 20px;font-weight: bold;font-size: 1.2em">
        Integration: ${integrationName}
    </div>
    <div style="padding: 10px 20px;">
        <p>Hello,</p>
        <p>This email includes the list of errors occurred in the integration '<strong>${integrationName}</strong>' since the last email</p>
        ${stepErrorSections}
    </div>
</article>`
    },
    stepErrorsSection: (flowName, errorRows) => {
      return `<div style="background-color: #76bc21; color: #FFFFFF; padding: 10px">
    ${flowName}
</div>
<table style="width:100%;border: 1px solid #9E9E9E;border-collapse: collapse;background-color: white;margin-bottom: 20px">
    <thead>
    <tr>
        <td style="padding: 10px;width: 25%; border: 1px solid #9E9E9E;border-collapse: collapse;font-weight: bold">Step Name</td>
        <td style="padding: 10px;width: 60%; border: 1px solid #9E9E9E;border-collapse: collapse;font-weight: bold">Message</td>
        <td style="padding: 10px;width: 25%; border: 1px solid #9E9E9E;border-collapse: collapse;font-weight: bold">Occurred At</td>
    </tr>
    </thead>
    <tbody>
    ${errorRows}
    </tbody>
</table>`
    },
    errorTableRow: (stepName, occurredAt, message) => {
      return `<tr>
            <td style="padding: 10px;border: 1px solid #9E9E9E;border-collapse: collapse;"><code>${stepName}</code></td>
    <td style="padding: 10px;border: 1px solid #9E9E9E;border-collapse: collapse;"><code>${message}</code></td>
    <td style="padding: 10px;border: 1px solid #9E9E9E;border-collapse: collapse;"><code>${occurredAt}</code></td>
    </td>
</tr>`
    }
  },
  
  emailMessage: (body, integrationName, to, from) => {
    return `Content-Type: multipart/mixed; boundary=celigo_email_bondary
MIME-Version: 1.0
to: ${to}
from: ${from}
subject: ${integrationName} - Error Summary Notification

--celigo_email_bondary
Content-Type: text/html; charset="UTF-8"
MIME-Version: 1.0

${body}

--celigo_email_bondary--`
  },
  
  processFlowErrors: (options) => {
    
    function concatenateObjectsByFlowId (objArray) {
      const result = {}
      
      objArray.forEach(obj => {
        const flowId = obj.flowId
        
        if (!result[flowId]) {
          result[flowId] = { flowName: obj.flowName, flowErrors: {} };
          const flowErrors = obj.flowErrors;
          result[flowId].flowErrors = {
            [obj.stepName]: flowErrors
          };
        } else {
          result[flowId].flowErrors[obj.stepName] = obj.flowErrors;
        }
      })
      return Object.values(result)
    }
    return options.data.map((d) => {
      
      let emailBody = false
      
      const flowData = options.data[0]
      
      let flowImportExportErrors = concatenateObjectsByFlowId(flowData.flowImportExportIds)
      
      let errors = []
      let stepErrorSections = []
      
      flowImportExportErrors.forEach(ele => {
        let errorRows = []
        if (ele.flowErrors && Object.keys(ele.flowErrors).length > 0) {
          const flowName = ele.flowName
          
          Object.entries(ele.flowErrors).forEach(errorsByStep => {
            const stepName = errorsByStep[0];
            const stepErrors = errorsByStep[1];
            stepErrors.forEach(err => {
              const occurredAt = err.occurredAt
              const code = err.code
              const message = err.message

              errorRows.push(
                ErrorSummaryEmail.emailBodyTemplates.errorTableRow(
                  stepName,
                  occurredAt,
                  message
                )
              )
            });
          })
          if (errorRows.length > 0) {
            stepErrorSections.push(
              ErrorSummaryEmail.emailBodyTemplates.stepErrorsSection(flowName, errorRows.join('\n'))
            )
          }
        }
      })
      
      if (stepErrorSections.length > 0) {
        emailBody = ErrorSummaryEmail.emailBodyTemplates.mainArticle(
          flowData.name,
          stepErrorSections.join('\n')
        )
      }
      
      const from = 'cs@orangehrmlive.com'
      const to = options.settings.integration.error_email_to
      
      if (emailBody != false) {
        emailBody = ErrorSummaryEmail.emailMessage(emailBody, flowData.name, to, from)
        d.emailBody = emailBody
        return {
          data: d
        }
      } else {
        return {
          data: null
        }
      }
    })
  },
  
  processFlowInfo: (options) => {
    const data = options.data[0]
    
    let imports = []
    let exports = []
    
    if (data._exportId && data._importId) {
      imports.push({ 'id': data._importId })
      exports.push({ 'id': data._exportId })
    } else {
      exports = exports.concat(data.pageGenerators.map(gen => {
        return { 'id': gen._exportId, 'type': 'export' }
      }))
      imports = imports.concat(data.pageProcessors.map(processor => {
        return processor.type === 'export' ? {
          'id': processor._exportId,
          'type': 'export'
        } : { 'id': processor._importId, 'type': 'import' }
      }))
    }
    
    return {
      data: [{
        'id': data.id,
        'name': data.name,
        'lastExecutedAt': data.lastExecutedAt,
        'imports_exports': imports.concat(exports)
      }],
      errors: options.errors,
      abort: false,
      newErrorsAndRetryData: []
    }
  },
  
  mergeFlowImportExportIds: (options) => {
    if (options.data[0]) {
      options.data[0].importExportIds = []
      if (options.data[0].exportIds && options.data[0].importIds) {
        options.data[0].importExportIds = options.data[0].exportIds.concat(options.data[0].importIds).map(id => {
          return { id }
        })
      } else if (options.data[0].exportIds) {
        options.data[0].importExportIds = options.data[0].exportIds.map(id => {
          return { id }
        })
      } else if (options.data[0].importIds) {
        options.data[0].importExportIds = options.data[0].importIds.map(id => {
          return { id }
        })
      }
    }
    return {
      data: options.data,
      errors: options.errors,
      abort: false,
      newErrorsAndRetryData: []
    }
  },
  
  mergeFlowImportExportsByIntegration: (options) => {
    const integration = options.postResponseMapData[0]
    const allFlows = integration.allFlows
    const integrationFlows = allFlows.filter(flow => flow.integrationId === integration.id)
    const flowImportExportIds = []
    integrationFlows.forEach(f => {
      const pgExportIds = f.pg_exportIds ? f.pg_exportIds : []
      const pgImportIds = f.pg_importIds ? f.pg_importIds : []
      const ppExportIds = f.pp_exportIds ? f.pp_exportIds : []
      const ppImportIds = f.pp_importIds ? f.pp_importIds : []
      pgExportIds.concat(ppExportIds).forEach(id => {
        flowImportExportIds.push({
          flowId: f.id,
          flowName: f.name,
          importExportId: id,
          stepType: 'export'
        })
      })
      pgImportIds.concat(ppImportIds).forEach(id => {
        flowImportExportIds.push({
          flowId: f.id,
          flowName: f.name,
          importExportId: id,
          stepType: 'import'
        })
      })
      
    })
    integration.flowImportExportIds = flowImportExportIds
    options.postResponseMapData[0] = integration
    delete integration.allFlows
    return options.postResponseMapData
  },
  
  mergeErrors: (options) => {
    const flowErrors = options.postResponseMapData[0].flowImportExportIds.map(imEx => {
      return imEx.flowErrors.map(e => {
        return {
          ...e,
          flowId: imEx.flowId,
          flowName: imEx.flowName,
          stepName: imEx.stepName,
          to: options.settings.integration.error_email_to
        }
      })
    })
    options.postResponseMapData[0].flowErrors = flowErrors
    return options.postResponseMapData
  },
  
  filterFlowsHavingErrors: (options) => {
    return options.data.map((d) => {
      if (d.flowErrors.length > 0) {
        return {
          data: d
        }
      }
    })
  },
}